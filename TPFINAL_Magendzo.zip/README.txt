Gabriel Magendzo

Raft Wars:

Description:
	The name of the term project is Raft Wars, it is a game in which you defeat waves of
enemies using a tennis ball launcher. As you move along the waves you the enemies get tougher and tougher. Use physics to your advantage in order to defeat the enemies. 

How to run:
	Open TermProjectV3.2.py and run it. You should have all the images and TpPhyiscsEngine2.py in the same folder that you have TermProjectV3.2.py.

Libraries:
	You must have Pillow in order to render the images.

No Shortcut Commands